# 2026 · UPanamericana · Math AI — Series de tiempo (ARIMA / SARIMA)

Materiales sobre modelado de series de tiempo con modelos **ARIMA** y **SARIMA**:
reportes en LaTeX y un cuaderno de análisis en Python.

## Contenido

| Archivo | Descripción |
|---|---|
| `Series_de_tiempo.ipynb` | Cuaderno de Python: simulación de una serie `SARIMA(0,1,1)(0,1,1)₁₂`, ajuste del modelo, pronóstico e intervalos de confianza. GitHub lo renderiza directamente. |
| `Sarima_TeX.tex` | Reporte LaTeX autocontenido sobre SARIMA (gráficas con TikZ/pgfplots). |
| `Sarima_TeX.pdf` | Versión compilada del reporte anterior (11 páginas). |
| `Arima___Sarima_Report_Regina_Flores.tex` | Reporte LaTeX sobre ARIMA/SARIMA. **Requiere una carpeta `figs/`** con las imágenes referenciadas (ver nota abajo). |

## Nota sobre `Arima___Sarima_Report_Regina_Flores.tex`

Este reporte incluye 8 figuras externas que deben colocarse en una subcarpeta `figs/`
junto al `.tex` para poder compilarlo:

```
figs/fig0_serie_exploratoria.pdf
figs/fig1_acfpacf_nivel.pdf
figs/fig2_acfpacf_diff.pdf
figs/fig3_ejemplo1_arima111.pdf
figs/fig4_ejemplo2_aicbic.pdf
figs/fig5_ejemplo3_sarima.pdf
figs/fig6_tabla_comparacion.pdf
figs/fig7_estacionariedad.pdf
```

Sin esa carpeta, el documento no compila completo.

## Cómo compilar los reportes LaTeX

```bash
pdflatex Sarima_TeX.tex
pdflatex Sarima_TeX.tex   # segunda pasada para índices y referencias cruzadas
```

## Cómo ejecutar el cuaderno

```bash
jupyter notebook Series_de_tiempo.ipynb
```

Dependencias principales: `numpy`, `pandas`, `matplotlib`, `statsmodels`.
